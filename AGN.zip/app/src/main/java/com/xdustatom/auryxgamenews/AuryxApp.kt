package com.xdustatom.auryxgamenews

import android.app.Application

class AuryxApp : Application()
